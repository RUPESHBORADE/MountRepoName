﻿using EmployeTask.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeTask.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeController(ApplicationDbContext context)
        {
            _context = context;
        }

        #region Index
        /// <summary>
        /// Index
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> Index()
        {
            var employees = await _context.Employees.ToListAsync();

            var employeeViewModels = employees.Select(employee =>
            {
                float dearnessAllowance = employee.BasicSalary * 0.40f;
                float conveyanceAllowance = Math.Min(dearnessAllowance * 0.10f, 250);
                float houseRentAllowance = Math.Max(employee.BasicSalary * 0.25f, 1500);
                float grossSalary = employee.BasicSalary + dearnessAllowance + conveyanceAllowance + houseRentAllowance;

                float professionalTax;
                if (grossSalary <= 3000)
                {
                    professionalTax = 100;
                }
                else if (grossSalary <= 6000)
                {
                    professionalTax = 150;
                }
                else
                {
                    professionalTax = 200;
                }

                float totalSalary = grossSalary - professionalTax;

                return new EmployeeViewModel
                {
                    Employee = employee,
                    DearnessAllowance = dearnessAllowance,
                    ConveyanceAllowance = conveyanceAllowance,
                    HouseRentAllowance = houseRentAllowance,
                    ProfessionalTax = professionalTax,
                    TotalSalary = totalSalary
                };
            }).ToList();

            return View(employeeViewModels);
        }

        #endregion

        #region Create
        /// <summary>
        /// Create
        /// </summary>
        /// <returns></returns>
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Create Post
        /// </summary>
        /// <param name="employee"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EmployeeCode,EmployeeName,DateOfBirth,Gender,Department,Designation,BasicSalary")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                // Calculate allowances and deductions
                float dearnessAllowance = employee.BasicSalary * 0.40f;
                float conveyanceAllowance = Math.Min(dearnessAllowance * 0.10f, 250); // Capped at 250
                float houseRentAllowance = Math.Max(employee.BasicSalary * 0.25f, 1500); // Minimum of 1500
                float grossSalary = employee.BasicSalary + dearnessAllowance + conveyanceAllowance + houseRentAllowance;

                float professionalTax;
                if (grossSalary <= 3000)
                {
                    professionalTax = 100; // Minimum tax
                }
                else if (grossSalary <= 6000)
                {
                    professionalTax = 150;
                }
                else
                {
                    professionalTax = 200; // Maximum tax
                }

                float totalSalary = grossSalary - professionalTax;

                _context.Add(employee);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(employee);
        }

        #endregion

        #region Edit
        /// <summary>
        /// Edit
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        /// <summary>
        /// Edit post
        /// </summary>
        /// <param name="id"></param>
        /// <param name="employee"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EmployeeCode,EmployeeName,DateOfBirth,Gender,Department,Designation,BasicSalary")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    employee.id = id;
                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.EmployeeCode))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }

        #endregion

        #region Delete
        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(m => m.id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        /// <summary>
        /// Delete Post
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }

            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        #endregion

        #region EmployeExist
        /// <summary>
        /// Employe Exist
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private bool EmployeeExists(int id)
        {
            return _context.Employees.Any(e => e.EmployeeCode == id);
        }
        #endregion

    }
}
