﻿using System.ComponentModel.DataAnnotations;

namespace EmployeTask.Models
{
    public class Employee
    {
        #region Model Filed

        [Key]
        public int? id {  get; set; }

        public int EmployeeCode { get; set; } 

        [Required]
        [StringLength(50)]
        public string EmployeeName { get; set; }

        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        [Required]
        public char Gender { get; set; }

        [StringLength(20)]
        public string Department { get; set; }

        [StringLength(20)]
        public string Designation { get; set; }

        [Range(0, double.MaxValue)]
        public float BasicSalary { get; set; }

        #endregion
    }
}
