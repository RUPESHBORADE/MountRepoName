﻿namespace EmployeTask.Models
{
    public class EmployeeViewModel
    {
        public Employee Employee { get; set; }
        public float DearnessAllowance { get; set; }
        public float ConveyanceAllowance { get; set; }
        public float HouseRentAllowance { get; set; }
        public float ProfessionalTax { get; set; }
        public float TotalSalary { get; set; }
    }
}
